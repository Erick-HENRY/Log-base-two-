var searchData=
[
  ['div_5fround_5fup',['DIV_ROUND_UP',['../group___g_e_n_e_r_i_c___m_a_t_h___g_r_o_u_p.html#gae664e7492e37d324831caf2321ddda37',1,'generic_math.h']]]
];
