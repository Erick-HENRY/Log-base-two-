var indexSectionsWithContent =
{
  0: "dgl",
  1: "g",
  2: "l",
  3: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "groups"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Fonctions",
  3: "Groupes"
};

